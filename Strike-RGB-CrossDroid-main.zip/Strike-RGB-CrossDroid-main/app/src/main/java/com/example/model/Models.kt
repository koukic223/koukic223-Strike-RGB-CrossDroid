package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.roundToInt

data class RgbColor(
    val r: Int = 0,
    val g: Int = 108,
    val b: Int = 232
) {
    fun toComposeColor(): Color = Color(r, g, b)

    fun toArgbInt(): Int = android.graphics.Color.rgb(r, g, b)

    fun toHex(): String = String.format("#%02X%02X%02X", r, g, b)

    fun luminance(): Float = (0.299f * r + 0.587f * g + 0.114f * b) / 255f

    fun isLight(): Boolean = luminance() > 0.5f

    companion object {
        val Blue = RgbColor(11, 87, 208)        // Pixel Blue
        val Purple = RgbColor(140, 79, 255)     // Pixel Violet
        val Green = RgbColor(30, 142, 62)       // Pixel Green
        val Mint = RgbColor(0, 168, 132)        // Pixel Mint
        val Coral = RgbColor(234, 67, 53)       // Pixel Coral Red
        val Amber = RgbColor(249, 171, 0)       // Pixel Amber
        val Cyan = RgbColor(0, 163, 196)        // Pixel Cyan
        val White = RgbColor(255, 255, 255)
        val Red = RgbColor(220, 38, 38)
        val Yellow = RgbColor(234, 179, 8)

        fun fromHsv(h: Float, s: Float, v: Float): RgbColor {
            val hsv = floatArrayOf(h, s, v)
            val colorInt = android.graphics.Color.HSVToColor(hsv)
            return RgbColor(
                r = android.graphics.Color.red(colorInt),
                g = android.graphics.Color.green(colorInt),
                b = android.graphics.Color.blue(colorInt)
            )
        }
    }
}

enum class EffectType(val displayNameKey: String) {
    STATIC("effect_static"),
    BREATHING("effect_breathing"),
    HEARTBEAT("effect_heartbeat"),
    PULSE("effect_pulse"),
    WAVE("effect_wave"),
    RAINBOW("effect_rainbow"),
    STROBE("effect_strobe"),
    SCREEN_SYNC("effect_screen_sync"),
    AMBILIGHT("effect_screen_sync")
}

enum class ScreenRegion(val displayNameKey: String) {
    FULL_SCREEN("region_full_screen"),
    TOP("region_top"),
    CENTER("region_center"),
    BOTTOM("region_bottom")
}

data class ScreenSyncConfig(
    val isEnabled: Boolean = false,
    val intensity: Float = 1.0f,            // 0f .. 1f
    val brightness: Float = 0.85f,          // 0f .. 1f
    val smoothing: Float = 0.50f,           // 0f .. 1f (Low / Med / High)
    val colorBoost: Boolean = true,
    val samplingRate: Int = 15,             // 10 .. 20 Hz
    val region: ScreenRegion = ScreenRegion.FULL_SCREEN,
    val keepColorOnScreenOff: Boolean = false
)

data class ScreenSyncDebugInfo(
    val isRunning: Boolean = false,
    val permissionGranted: Boolean = false,
    val detectedColor: RgbColor = RgbColor(0, 0, 0),
    val smoothedLedColor: RgbColor = RgbColor(0, 0, 0),
    val currentFps: Int = 0,
    val isRootAvailable: Boolean = false,
    val isLedDetected: Boolean = false
)

data class EffectEngineDiagnostic(
    val effect: EffectType = EffectType.STATIC,
    val isRunning: Boolean = false,
    val currentFps: Int = 0,
    val currentRgb: RgbColor = RgbColor(0, 0, 0),
    val frameCount: Long = 0L,
    val isRootAvailable: Boolean = false,
    val isLedDetected: Boolean = false,
    val lastError: String? = null
)

data class LedState(
    val isRunning: Boolean = true,
    val currentColor: RgbColor = RgbColor.Blue,
    val currentEffect: EffectType = EffectType.STATIC,
    val brightness: Float = 0.85f,          // 0f .. 1f
    val effectSpeed: Float = 1.0f,          // 0.2f .. 3.0f
    val breathingSpeed: Float = 2.0f,       // in seconds
    val intensity: Float = 1.0f,            // 0f .. 1f (Effect amplitude)
    val smoothTransition: Boolean = true,
    val saveLastEffect: Boolean = true,
    val screenSyncConfig: ScreenSyncConfig = ScreenSyncConfig(),
    val screenSyncDebugInfo: ScreenSyncDebugInfo = ScreenSyncDebugInfo()
)

enum class RootStatus {
    ROOT_AVAILABLE,
    ROOT_GRANTED,
    ROOT_DENIED,
    ROOT_NOT_FOUND,
    ROOT_ERROR,
    ROOT_REVOKED
}

enum class HardwareMode {
    ROOT,
    NON_ROOT,
    UNAVAILABLE
}

data class CommandResult(
    val success: Boolean,
    val exitCode: Int,
    val stdout: String,
    val stderr: String
)

data class HardwareTestResult(
    val success: Boolean,
    val message: String,
    val errorDetails: String? = null
)

data class HardwareStatus(
    val isRootConnected: Boolean = false,
    val isLedDetected: Boolean = false,
    val ledPath: String = "/sys/class/leds/red",
    val chipModel: String = "Standard sysfs LED",
    val uid: Int? = null,
    val apiLevel: Int = android.os.Build.VERSION.SDK_INT,
    val minAndroidVersion: String = "Android 2.1 (API 7)",
    val isHardwareTestRunning: Boolean = false,
    val rootStatus: RootStatus = RootStatus.ROOT_NOT_FOUND,
    val rootProvider: String = "Magisk / SU",
    val hardwareMode: HardwareMode = HardwareMode.UNAVAILABLE,
    val driver: String = "generic-leds",
    val redPath: String? = null,
    val greenPath: String? = null,
    val bluePath: String? = null,
    val isRedAvailable: Boolean = false,
    val isGreenAvailable: Boolean = false,
    val isBlueAvailable: Boolean = false,
    val maxBrightness: Int = 255,
    val statusMessage: String? = null
)

enum class AppLanguage(val code: String, val title: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    FRENCH("fr", "French", "Français"),
    ARABIC("ar", "Arabic", "العربية"),
    DARIJA("ary", "Darija", "الدارجة")
}

enum class AppThemeMode(val titleKey: String) {
    SYSTEM("theme_system"),
    LIGHT("theme_light"),
    DARK("theme_dark")
}

data class AppSettings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val startOnBoot: Boolean = false,
    val screenColor: Boolean = false,
    val smoothTransition: Boolean = true,
    val saveLastEffect: Boolean = true,
    val keepLedOnScreenOff: Boolean = true,
    val samplingRate: Int = 30,             // Hz (10 .. 60)
    val sensitivity: Float = 0.75f,         // 0f .. 1f
    val smoothing: Float = 0.50f,           // 0f .. 1f
    val defaultEffect: EffectType = EffectType.STATIC,
    val screenSyncConfig: ScreenSyncConfig = ScreenSyncConfig(),
    val customBackgroundPath: String? = null,
    val backgroundBlurIntensity: Float = 0.0f,     // 0f .. 1f (0% sharp, 100% heavy blur)
    val backgroundOverlay: Float = 0.30f           // 0f .. 1f (overlay tint darkness/brightness for legibility)
)
