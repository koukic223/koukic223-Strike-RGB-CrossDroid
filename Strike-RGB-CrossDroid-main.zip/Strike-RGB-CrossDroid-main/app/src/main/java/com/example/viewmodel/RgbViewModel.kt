package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hardware.HardwareController
import com.example.hardware.LedHardwareController
import com.example.hardware.RootManager
import com.example.model.AppLanguage
import com.example.model.AppSettings
import com.example.model.AppThemeMode
import com.example.model.EffectType
import com.example.model.HardwareStatus
import com.example.model.HardwareTestResult
import com.example.model.LedState
import com.example.model.RgbColor
import com.example.model.RootStatus
import com.example.effects.EffectEngine
import com.example.effects.screensync.MediaProjectionHolder
import com.example.model.EffectEngineDiagnostic
import com.example.model.ScreenRegion
import com.example.model.ScreenSyncConfig
import com.example.model.ScreenSyncDebugInfo
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.example.service.LedControlService
import com.example.ui.background.CustomBackgroundManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class RgbViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("koukou_rgb_prefs", Context.MODE_PRIVATE)
    private val hardwareController = HardwareController()
    private val ledHardwareController = hardwareController.controller

    private val _ledState = MutableStateFlow(loadInitialLedState())
    val ledState: StateFlow<LedState> = _ledState.asStateFlow()

    private val _hardwareStatus = MutableStateFlow(hardwareController.checkHardwareStatus())
    val hardwareStatus: StateFlow<HardwareStatus> = _hardwareStatus.asStateFlow()

    private val _appSettings = MutableStateFlow(loadInitialSettings())
    val appSettings: StateFlow<AppSettings> = _appSettings.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val effectEngine: EffectEngine = EffectEngine.getInstance(application)
    val effectDiagnostic: StateFlow<EffectEngineDiagnostic> = effectEngine.diagnosticFlow
    val screenSyncDebugInfo: StateFlow<ScreenSyncDebugInfo> = LedControlService.debugInfoFlow

    init {
        refreshHardwareStatus()
        applyHardwareChanges()
        val bgPath = _appSettings.value.customBackgroundPath
        if (!bgPath.isNullOrEmpty()) {
            CustomBackgroundManager.loadFromPath(bgPath)
        }
    }

    fun refreshHardwareStatus() {
        viewModelScope.launch {
            val status = ledHardwareController.detectLEDs()
            _hardwareStatus.value = status
        }
    }

    private fun loadInitialLedState(): LedState {
        val r = prefs.getInt("led_r", RgbColor.Blue.r)
        val g = prefs.getInt("led_g", RgbColor.Blue.g)
        val b = prefs.getInt("led_b", RgbColor.Blue.b)
        val effectName = prefs.getString("led_effect", EffectType.STATIC.name) ?: EffectType.STATIC.name
        val effect = try { EffectType.valueOf(effectName) } catch (_: Exception) { EffectType.STATIC }
        val brightness = prefs.getFloat("led_brightness", 0.85f)
        val speed = prefs.getFloat("led_speed", 1.0f)
        val breathingSpeed = prefs.getFloat("led_breathing_speed", 2.0f)
        val isRunning = prefs.getBoolean("led_running", true)

        val syncIntensity = prefs.getFloat("setting_sync_intensity", 1.0f)
        val syncSmoothing = prefs.getFloat("setting_sync_smoothing", 0.50f)
        val syncColorBoost = prefs.getBoolean("setting_sync_color_boost", true)
        val syncSamplingRate = prefs.getInt("setting_sync_sampling_rate", 15)
        val syncRegionName = prefs.getString("setting_sync_region", ScreenRegion.FULL_SCREEN.name) ?: ScreenRegion.FULL_SCREEN.name
        val syncRegion = try { ScreenRegion.valueOf(syncRegionName) } catch (_: Exception) { ScreenRegion.FULL_SCREEN }
        val syncKeepOff = prefs.getBoolean("setting_sync_keep_off", false)

        val syncConfig = ScreenSyncConfig(
            isEnabled = effect == EffectType.SCREEN_SYNC,
            intensity = syncIntensity,
            brightness = brightness,
            smoothing = syncSmoothing,
            colorBoost = syncColorBoost,
            samplingRate = syncSamplingRate,
            region = syncRegion,
            keepColorOnScreenOff = syncKeepOff
        )

        return LedState(
            isRunning = isRunning,
            currentColor = RgbColor(r, g, b),
            currentEffect = effect,
            brightness = brightness,
            effectSpeed = speed,
            breathingSpeed = breathingSpeed,
            screenSyncConfig = syncConfig
        )
    }

    private fun loadInitialSettings(): AppSettings {
        val langName = prefs.getString("setting_lang", AppLanguage.ENGLISH.name) ?: AppLanguage.ENGLISH.name
        val lang = try { AppLanguage.valueOf(langName) } catch (_: Exception) { AppLanguage.ENGLISH }

        val themeName = prefs.getString("setting_theme", AppThemeMode.SYSTEM.name) ?: AppThemeMode.SYSTEM.name
        val theme = try { AppThemeMode.valueOf(themeName) } catch (_: Exception) { AppThemeMode.SYSTEM }

        val dynamicColor = prefs.getBoolean("setting_dynamic_color", true)
        val startOnBoot = prefs.getBoolean("setting_start_boot", false)
        val screenColor = prefs.getBoolean("setting_screen_color", false)
        val smoothTransition = prefs.getBoolean("setting_smooth_transition", true)
        val saveLastEffect = prefs.getBoolean("setting_save_last_effect", true)
        val keepScreenOff = prefs.getBoolean("setting_keep_screen_off", true)
        val samplingRate = prefs.getInt("setting_sampling_rate", 30)
        val sensitivity = prefs.getFloat("setting_sensitivity", 0.75f)
        val smoothing = prefs.getFloat("setting_smoothing", 0.50f)

        val syncIntensity = prefs.getFloat("setting_sync_intensity", 1.0f)
        val syncSmoothing = prefs.getFloat("setting_sync_smoothing", 0.50f)
        val syncColorBoost = prefs.getBoolean("setting_sync_color_boost", true)
        val syncSamplingRate = prefs.getInt("setting_sync_sampling_rate", 15)
        val syncRegionName = prefs.getString("setting_sync_region", ScreenRegion.FULL_SCREEN.name) ?: ScreenRegion.FULL_SCREEN.name
        val syncRegion = try { ScreenRegion.valueOf(syncRegionName) } catch (_: Exception) { ScreenRegion.FULL_SCREEN }
        val syncKeepOff = prefs.getBoolean("setting_sync_keep_off", false)
        val customBgPath = prefs.getString("setting_custom_bg_path", null)
        val bgBlur = prefs.getFloat("setting_bg_blur", 0.0f)
        val bgOverlay = prefs.getFloat("setting_bg_overlay", 0.30f)

        val syncConfig = ScreenSyncConfig(
            isEnabled = false,
            intensity = syncIntensity,
            brightness = 0.85f,
            smoothing = syncSmoothing,
            colorBoost = syncColorBoost,
            samplingRate = syncSamplingRate,
            region = syncRegion,
            keepColorOnScreenOff = syncKeepOff
        )

        return AppSettings(
            language = lang,
            themeMode = theme,
            dynamicColor = dynamicColor,
            startOnBoot = startOnBoot,
            screenColor = screenColor,
            smoothTransition = smoothTransition,
            saveLastEffect = saveLastEffect,
            keepLedOnScreenOff = keepScreenOff,
            samplingRate = samplingRate,
            sensitivity = sensitivity,
            smoothing = smoothing,
            screenSyncConfig = syncConfig,
            customBackgroundPath = customBgPath,
            backgroundBlurIntensity = bgBlur,
            backgroundOverlay = bgOverlay
        )
    }

    private fun persistSettings() {
        val s = _appSettings.value
        val l = _ledState.value
        val sync = l.screenSyncConfig
        prefs.edit()
            .putInt("led_r", l.currentColor.r)
            .putInt("led_g", l.currentColor.g)
            .putInt("led_b", l.currentColor.b)
            .putString("led_effect", l.currentEffect.name)
            .putFloat("led_brightness", l.brightness)
            .putFloat("led_speed", l.effectSpeed)
            .putFloat("led_breathing_speed", l.breathingSpeed)
            .putBoolean("led_running", l.isRunning)
            .putString("setting_lang", s.language.name)
            .putString("setting_theme", s.themeMode.name)
            .putBoolean("setting_dynamic_color", s.dynamicColor)
            .putBoolean("setting_start_boot", s.startOnBoot)
            .putBoolean("setting_screen_color", s.screenColor)
            .putBoolean("setting_smooth_transition", s.smoothTransition)
            .putBoolean("setting_save_last_effect", s.saveLastEffect)
            .putBoolean("setting_keep_screen_off", s.keepLedOnScreenOff)
            .putInt("setting_sampling_rate", s.samplingRate)
            .putFloat("setting_sensitivity", s.sensitivity)
            .putFloat("setting_smoothing", s.smoothing)
            .putFloat("setting_sync_intensity", sync.intensity)
            .putFloat("setting_sync_smoothing", sync.smoothing)
            .putBoolean("setting_sync_color_boost", sync.colorBoost)
            .putInt("setting_sync_sampling_rate", sync.samplingRate)
            .putString("setting_sync_region", sync.region.name)
            .putBoolean("setting_sync_keep_off", sync.keepColorOnScreenOff)
            .putString("setting_custom_bg_path", s.customBackgroundPath)
            .putFloat("setting_bg_blur", s.backgroundBlurIntensity)
            .putFloat("setting_bg_overlay", s.backgroundOverlay)
            .apply()
    }

    private fun syncService() {
        val state = _ledState.value
        val keepOff = _appSettings.value.keepLedOnScreenOff
        val app = getApplication<Application>()
        if (state.isRunning) {
            LedControlService.update(app, state, keepOff)
        } else {
            LedControlService.stop(app)
        }
    }

    private fun applyHardwareChanges() {
        viewModelScope.launch {
            val state = _ledState.value
            effectEngine.updateState(state)
            syncService()
        }
    }

    fun startLed() {
        _ledState.update { it.copy(isRunning = true) }
        applyHardwareChanges()
        persistSettings()
    }

    fun stopLed() {
        _ledState.update { it.copy(isRunning = false) }
        applyHardwareChanges()
        persistSettings()
    }

    fun setColor(color: RgbColor) {
        _ledState.update { it.copy(currentColor = color) }
        applyHardwareChanges()
        if (_appSettings.value.saveLastEffect) {
            persistSettings()
        }
    }

    fun setEffect(effect: EffectType) {
        _ledState.update { it.copy(currentEffect = effect, isRunning = true) }
        applyHardwareChanges()
        if (_appSettings.value.saveLastEffect) {
            persistSettings()
        }
    }

    fun setBrightness(brightness: Float) {
        _ledState.update { it.copy(brightness = brightness.coerceIn(0f, 1f)) }
        applyHardwareChanges()
    }

    fun setIntensity(intensity: Float) {
        _ledState.update { it.copy(intensity = intensity.coerceIn(0f, 1f)) }
        applyHardwareChanges()
    }

    fun setEffectSpeed(speed: Float) {
        _ledState.update { it.copy(effectSpeed = speed.coerceIn(0.2f, 3.0f)) }
        applyHardwareChanges()
    }

    fun setBreathingSpeed(speed: Float) {
        _ledState.update { it.copy(breathingSpeed = speed.coerceIn(0.5f, 5.0f)) }
        applyHardwareChanges()
    }

    fun setKeepLedOnScreenOff(enabled: Boolean) {
        _appSettings.update { it.copy(keepLedOnScreenOff = enabled) }
        persistSettings()
        syncService()
    }

    fun setDynamicColor(enabled: Boolean) {
        _appSettings.update { it.copy(dynamicColor = enabled) }
        persistSettings()
    }

    fun setLanguage(lang: AppLanguage) {
        _appSettings.update { it.copy(language = lang) }
        persistSettings()
    }

    fun setThemeMode(mode: AppThemeMode) {
        _appSettings.update { it.copy(themeMode = mode) }
        persistSettings()
    }

    fun setStartOnBoot(enabled: Boolean) {
        _appSettings.update { it.copy(startOnBoot = enabled) }
        persistSettings()
    }

    fun setScreenColor(enabled: Boolean) {
        _appSettings.update { it.copy(screenColor = enabled) }
        persistSettings()
    }

    fun setSmoothTransition(enabled: Boolean) {
        _appSettings.update { it.copy(smoothTransition = enabled) }
        persistSettings()
    }

    fun setSaveLastEffect(enabled: Boolean) {
        _appSettings.update { it.copy(saveLastEffect = enabled) }
        persistSettings()
    }

    fun setSamplingRate(rate: Int) {
        _appSettings.update { it.copy(samplingRate = rate.coerceIn(10, 60)) }
        persistSettings()
    }

    fun setSensitivity(sens: Float) {
        _appSettings.update { it.copy(sensitivity = sens.coerceIn(0f, 1f)) }
        persistSettings()
    }

    fun setSmoothing(smooth: Float) {
        _appSettings.update { it.copy(smoothing = smooth.coerceIn(0f, 1f)) }
        persistSettings()
    }

    fun updateScreenSyncConfig(transform: (ScreenSyncConfig) -> ScreenSyncConfig) {
        _ledState.update { current ->
            val updated = transform(current.screenSyncConfig)
            current.copy(screenSyncConfig = updated)
        }
        _appSettings.update { current ->
            val updated = transform(current.screenSyncConfig)
            current.copy(screenSyncConfig = updated)
        }
        syncService()
        persistSettings()
    }

    fun setScreenSyncIntensity(intensity: Float) {
        updateScreenSyncConfig { it.copy(intensity = intensity.coerceIn(0f, 1f)) }
    }

    fun setScreenSyncSmoothing(smoothing: Float) {
        updateScreenSyncConfig { it.copy(smoothing = smoothing.coerceIn(0f, 1f)) }
    }

    fun setScreenSyncColorBoost(enabled: Boolean) {
        updateScreenSyncConfig { it.copy(colorBoost = enabled) }
    }

    fun setScreenSyncSamplingRate(rate: Int) {
        updateScreenSyncConfig { it.copy(samplingRate = rate.coerceIn(10, 20)) }
    }

    fun setScreenSyncRegion(region: ScreenRegion) {
        updateScreenSyncConfig { it.copy(region = region) }
    }

    fun setScreenSyncKeepColorOnScreenOff(enabled: Boolean) {
        updateScreenSyncConfig { it.copy(keepColorOnScreenOff = enabled) }
    }

    fun onMediaProjectionGranted(resultCode: Int, data: Intent?) {
        MediaProjectionHolder.setPermission(resultCode, data)
        _ledState.update { it.copy(currentEffect = EffectType.SCREEN_SYNC, isRunning = true) }
        applyHardwareChanges()
        persistSettings()
    }

    fun setDefaultEffect(effect: EffectType) {
        _appSettings.update { it.copy(defaultEffect = effect) }
        _ledState.update { it.copy(currentEffect = effect) }
        persistSettings()
    }

    fun runHardwareTest(onComplete: (HardwareTestResult) -> Unit) {
        viewModelScope.launch {
            _hardwareStatus.update { it.copy(isHardwareTestRunning = true) }
            val result = ledHardwareController.testRGB { stepMsg, stepColor ->
                _statusMessage.value = stepMsg
                _ledState.update { it.copy(currentColor = stepColor, isRunning = true) }
            }
            _hardwareStatus.update { it.copy(isHardwareTestRunning = false) }
            _statusMessage.value = null
            applyHardwareChanges()
            refreshHardwareStatus()
            onComplete(result)
        }
    }

    /**
     * Section 25 Hardware Verification: Tests 255,0,0, 0,255,0, 0,0,255 and alternates 6 colors.
     */
    fun runPipelineColorTest(onComplete: (HardwareTestResult) -> Unit) {
        viewModelScope.launch {
            _hardwareStatus.update { it.copy(isHardwareTestRunning = true) }
            val result = hardwareController.runPipelineColorTest { stepMsg, stepColor ->
                _statusMessage.value = stepMsg
                _ledState.update { it.copy(currentColor = stepColor, isRunning = true) }
            }
            _hardwareStatus.update { it.copy(isHardwareTestRunning = false) }
            _statusMessage.value = null
            applyHardwareChanges()
            refreshHardwareStatus()
            onComplete(result)
        }
    }

    /**
     * Direct test mode: forces real-time animation of selected effect on physical LED.
     */
    fun testEffectDirect(effect: EffectType) {
        _ledState.update { it.copy(currentEffect = effect, isRunning = true) }
        effectEngine.testEffect(effect)
        syncService()
    }

    /**
     * Checks current root authorization status via real SU execution.
     */
    fun checkRoot(onResult: ((RootStatus) -> Unit)? = null) {
        viewModelScope.launch {
            _statusMessage.value = "Checking Root Authorization..."
            val (status, uid) = RootManager.determineRootStatus()
            val hwStatus = ledHardwareController.detectLEDs()
            _hardwareStatus.value = hwStatus
            _statusMessage.value = null
            onResult?.invoke(status)
        }
    }

    /**
     * Requests root access via `su -c id`.
     * This triggers the Magisk / Superuser dialog on real rooted devices.
     */
    fun requestRoot(onResult: ((RootStatus) -> Unit)? = null) {
        viewModelScope.launch {
            _statusMessage.value = "Requesting Magisk Superuser permission..."
            val result = RootManager.requestRoot()
            val uid = RootManager.parseUid(result.stdout)
            val status = when {
                result.exitCode == 0 && uid == 0 -> RootStatus.ROOT_GRANTED
                result.stdout.contains("uid=0") -> RootStatus.ROOT_GRANTED
                result.stderr.contains("denied", ignoreCase = true) -> RootStatus.ROOT_DENIED
                !RootManager.isRootAvailable() -> RootStatus.ROOT_NOT_FOUND
                else -> RootStatus.ROOT_ERROR
            }
            val hwStatus = ledHardwareController.detectLEDs()
            _hardwareStatus.value = hwStatus
            _statusMessage.value = null
            onResult?.invoke(status)
        }
    }

    fun setCustomBackgroundUri(uri: Uri, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val inputStream = app.contentResolver.openInputStream(uri)
                if (inputStream == null) {
                    onResult(false)
                    return@launch
                }
                val destFile = File(app.filesDir, "custom_background.jpg")
                val tempBytes = inputStream.use { it.readBytes() }

                // Decode with sample size to fit 540x960 device memory safely
                val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(tempBytes, 0, tempBytes.size, boundsOptions)

                var inSampleSize = 1
                val maxDim = max(boundsOptions.outWidth, boundsOptions.outHeight)
                while (maxDim / inSampleSize > 1280) {
                    inSampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    this.inSampleSize = inSampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bitmap = BitmapFactory.decodeByteArray(tempBytes, 0, tempBytes.size, decodeOptions)
                if (bitmap != null) {
                    FileOutputStream(destFile).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    CustomBackgroundManager.loadAndCache(bitmap)
                    _appSettings.update {
                        it.copy(customBackgroundPath = destFile.absolutePath)
                    }
                    persistSettings()
                    onResult(true)
                } else {
                    onResult(false)
                }
            } catch (e: Exception) {
                Log.e("RgbViewModel", "Failed to save custom background", e)
                onResult(false)
            }
        }
    }

    fun setBackgroundBlurIntensity(value: Float) {
        val clamped = value.coerceIn(0f, 1f)
        _appSettings.update { it.copy(backgroundBlurIntensity = clamped) }
        persistSettings()
    }

    fun setBackgroundOverlay(value: Float) {
        val clamped = value.coerceIn(0f, 1f)
        _appSettings.update { it.copy(backgroundOverlay = clamped) }
        persistSettings()
    }

    fun resetCustomBackground() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val file = File(app.filesDir, "custom_background.jpg")
                if (file.exists()) {
                    file.delete()
                }
            } catch (_: Exception) {}
            CustomBackgroundManager.clear()
            _appSettings.update {
                it.copy(customBackgroundPath = null)
            }
            persistSettings()
        }
    }

    fun saveAll() {
        persistSettings()
    }

    fun resetSettings() {
        _ledState.value = LedState()
        _appSettings.value = AppSettings()
        persistSettings()
        applyHardwareChanges()
    }
}
