package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.model.AppLanguage
import com.example.model.LedState
import com.example.model.RgbColor
import com.example.ui.components.PixelButton
import com.example.ui.components.PixelCard
import com.example.ui.components.PixelSectionTitle
import com.example.ui.components.PixelSliderItem
import com.example.ui.components.PixelTonalButton
import kotlin.math.roundToInt

@Composable
fun ColorPickerScreen(
    ledState: LedState,
    language: AppLanguage,
    onColorChanged: (RgbColor) -> Unit,
    onBrightnessChanged: (Float) -> Unit,
    onApply: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var redVal by remember(ledState.currentColor) { mutableIntStateOf(ledState.currentColor.r) }
    var greenVal by remember(ledState.currentColor) { mutableIntStateOf(ledState.currentColor.g) }
    var blueVal by remember(ledState.currentColor) { mutableIntStateOf(ledState.currentColor.b) }

    val currentColor = remember(redVal, greenVal, blueVal) {
        RgbColor(redVal, greenVal, blueVal)
    }

    val pixelPalette = listOf(
        RgbColor(11, 87, 208),     // Pixel Blue
        RgbColor(140, 79, 255),    // Pixel Violet
        RgbColor(0, 168, 132),     // Pixel Mint
        RgbColor(52, 168, 83),     // Google Green
        RgbColor(251, 188, 4),     // Google Yellow
        RgbColor(234, 67, 53),     // Google Coral Red
        RgbColor(0, 163, 196),     // Pixel Cyan
        RgbColor(255, 110, 180),   // Hot Pink
        RgbColor(255, 153, 0),     // Deep Amber
        RgbColor(186, 26, 26),     // Crimson
        RgbColor(79, 195, 247),    // Light Sky
        RgbColor(255, 255, 255)    // Pure White
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Title (Section 62: Choose LED Color)
        Text(
            text = Strings.get("choose_led_color", language),
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier
                .align(Alignment.Start)
                .padding(top = 8.dp, bottom = 12.dp)
        )

        // Center: Large Circular Color Preview (Section 62)
        Box(
            modifier = Modifier
                .padding(vertical = 12.dp)
                .size(140.dp),
            contentAlignment = Alignment.Center
        ) {
            // Ambient diffused halo
            Box(
                modifier = Modifier
                    .size(136.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                currentColor.toComposeColor().copy(alpha = 0.5f),
                                currentColor.toComposeColor().copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        )
                    )
            )

            // Inner solid preview disc
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(currentColor.toComposeColor())
                    .border(
                        3.dp,
                        MaterialTheme.colorScheme.surfaceContainerHigh,
                        CircleShape
                    )
                    .shadow(elevation = 6.dp, shape = CircleShape)
                    .testTag("circular_color_preview")
            )
        }

        // Hex & Luminance info chip
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceContainer)
                .padding(horizontal = 18.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentColor.toHex(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "RGB(${currentColor.r}, ${currentColor.g}, ${currentColor.b})",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preset Swatches Card
        PixelCard {
            Column {
                Text(
                    text = Strings.get("preset_colors", language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (preset in pixelPalette.take(6)) {
                        val isSel = currentColor == preset
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(preset.toComposeColor())
                                .border(
                                    if (isSel) 3.dp else 1.dp,
                                    if (isSel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                    CircleShape
                                )
                                .clickable {
                                    redVal = preset.r
                                    greenVal = preset.g
                                    blueVal = preset.b
                                    onColorChanged(preset)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSel) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (preset.isLight()) Color.Black else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (preset in pixelPalette.drop(6).take(6)) {
                        val isSel = currentColor == preset
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(preset.toComposeColor())
                                .border(
                                    if (isSel) 3.dp else 1.dp,
                                    if (isSel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                    CircleShape
                                )
                                .clickable {
                                    redVal = preset.r
                                    greenVal = preset.g
                                    blueVal = preset.b
                                    onColorChanged(preset)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSel) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (preset.isLight()) Color.Black else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // RGB Values Sliders (Section 62: Below: RGB values R, G, B)
        PixelCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = Strings.get("rgb_values", language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                // R Slider
                PixelSliderItem(
                    title = "R (${redVal})",
                    value = redVal / 255f,
                    onValueChange = {
                        redVal = (it * 255).roundToInt()
                        onColorChanged(RgbColor(redVal, greenVal, blueVal))
                    },
                    displayFormatter = { "$redVal" },
                    testTag = "slider_r"
                )

                // G Slider
                PixelSliderItem(
                    title = "G (${greenVal})",
                    value = greenVal / 255f,
                    onValueChange = {
                        greenVal = (it * 255).roundToInt()
                        onColorChanged(RgbColor(redVal, greenVal, blueVal))
                    },
                    displayFormatter = { "$greenVal" },
                    testTag = "slider_g"
                )

                // B Slider
                PixelSliderItem(
                    title = "B (${blueVal})",
                    value = blueVal / 255f,
                    onValueChange = {
                        blueVal = (it * 255).roundToInt()
                        onColorChanged(RgbColor(redVal, greenVal, blueVal))
                    },
                    displayFormatter = { "$blueVal" },
                    testTag = "slider_b"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Brightness Slider (Section 62: Brightness slider)
        PixelCard {
            PixelSliderItem(
                title = Strings.get("brightness", language),
                value = ledState.brightness,
                onValueChange = onBrightnessChanged,
                valueRange = 0.05f..1.0f,
                icon = Icons.Default.Lightbulb,
                displayFormatter = { "${(it * 100).roundToInt()}%" },
                testTag = "color_picker_brightness_slider"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Buttons: APPLY & SAVE (Section 62)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            PixelButton(
                text = Strings.get("apply", language),
                onClick = onApply,
                modifier = Modifier.weight(1f),
                testTag = "color_picker_apply_button"
            )

            PixelTonalButton(
                text = Strings.get("save", language),
                onClick = onSave,
                modifier = Modifier.weight(1f),
                testTag = "color_picker_save_button"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
